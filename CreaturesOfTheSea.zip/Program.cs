﻿using System;

namespace CreaturesOfTheSea
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            Goldfish swimShady = new Goldfish()
            {
                Name = "Swim Shady",
                Age = 1,
                Color = "Orange",
                NumberOfFins = 1
            };

            swimShady.Eat();


            Reptile waterDragon = new Reptile()
            {
                Name = "Mr Dragon",
                Age = 2,
                Color = "Green",
                HasTail = true
            };

            waterDragon.Eat();

        }
    }
}
