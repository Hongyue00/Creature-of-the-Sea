﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreaturesOfTheSea
{
    public class Fish : Creature
    {
        public int NumberOfFins { get; set; }
        //public Fish(string name, int age, string color)
        //{
        //    Name = name;
        //    Age = age;
        //    Color = color;
        //}

        public override void Eat()
        {
            Console.WriteLine($"{Name} FISH EAT");
        }

        public override void Swim()
        {
            Console.WriteLine($"{Name} FISH Swim");
        }
    }
}
